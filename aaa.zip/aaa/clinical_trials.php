<?php
include "componet/header.php";
include "componet/sidebar.php";
?>
<div class="container-fluid pt-4 px-4">
    <div class="col-12">
        <div class="bg-light rounded py-5 bg-light border border-info h-100 p-4">
            <h2>Add New Clinical Trial</h2>
            <form action="php/add_clinical_trial.php" method="POST">
                <!-- Title -->
                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" class="form-control" id="title" name="title" required
                        placeholder="Enter clinical trial title">
                </div>
                <!-- Description -->
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="4"
                        placeholder="Enter clinical trial description"></textarea>
                </div>
                <!-- Status -->
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="">Select status</option>
                        <option value="recruiting">Recruiting</option>
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <!-- Start Date -->
                <div class="mb-3">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" required>
                </div>
                <!-- End Date -->
                <div class="mb-3">
                    <label for="end_date" class="form-label">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" required>
                </div>
                <!-- Submit Button -->
                <button type="submit" class="btn btn-info">Add Clinical Trial</button>
            </form>
        </div>
    </div>
</div>

<?php
// Define the JSON file path
$file_path = 'db/clinical_trials.json';

// Initialize an empty array to hold the data
$data = [];

// Check if the JSON file exists
if (file_exists($file_path)) {
    // Read the existing data from the JSON file
    $data = json_decode(file_get_contents($file_path), true);
} else {
    echo "Error: JSON file not found.";
}
?>
<div class="container-fluid pt-4 px-4">
<div class="col-12">
    <div class="bg-light rounded py-5 border border-info h-100 p-4">
        <h6 class="mb-4">Patient Records</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-info">
                    <tr>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Status</th>
                        <th scope="col">Start Date</th>
                        <th scope="col">End Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($data)): ?>
                        <?php foreach ($data as $trial): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($trial['title']); ?></td>
                                <td><?php echo htmlspecialchars($trial['description']); ?></td>
                                <td><?php echo htmlspecialchars($trial['status']); ?></td>
                                <td><?php echo htmlspecialchars($trial['start_date']); ?></td>
                                <td><?php echo htmlspecialchars($trial['end_date']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">No records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>


<div class="container-fluid pt-4 px-4">
    <div class="col-12">
        <div class="bg-light rounded py-5 bg-light border border-info h-100 p-4">
            <h6 class="mb-4">Clinical Trials Table</h6>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Status</th>
                            <th scope="col">Start Date</th>
                            <th scope="col">End Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Trial Title 1</td>
                            <td>Brief description of the trial.</td>
                            <td>Recruiting</td>
                            <td>2023-05-01</td>
                            <td>2024-05-01</td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Trial Title 2</td>
                            <td>Another trial description.</td>
                            <td>Ongoing</td>
                            <td>2022-06-15</td>
                            <td>2023-06-15</td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Trial Title 3</td>
                            <td>Additional information about the trial.</td>
                            <td>Completed</td>
                            <td>2021-08-10</td>
                            <td>2022-08-10</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid pt-4 px-4">
    <div class="col-12">
        <div class="bg-light rounded py-5 bg-light border border-info h-100 p-4">
            <h5>Search Clinical Trials</h5>
            <div class="row">
                <div class="col-md-3">
                    <input type="text" class="form-control" placeholder="Keyword" aria-label="Search">
                </div>
                <div class="col-md-3">
                    <select class="form-select">
                        <option selected>Cancer Type</option>
                        <option value="1">Lung Cancer</option>
                        <option value="2">Breast Cancer</option>
                        <option value="3">Prostate Cancer</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select">
                        <option selected>Stage</option>
                        <option value="1">Stage I</option>
                        <option value="2">Stage II</option>
                        <option value="3">Stage III</option>
                        <option value="4">Stage IV</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-info w-100">Search</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header bg-info text-white">Trial Phase II</div>
                <div class="card-body">
                    <h5 class="card-title">Trial on Immunotherapy for Lung Cancer</h5>
                    <p class="card-text">Location: Cancer Research Institute</p>
                    <p class="card-text">Status: Recruiting</p>
                    <a href="#" class="btn btn-outline-info">View Details</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header bg-info text-white">Trial Phase III</div>
                <div class="card-body">
                    <h5 class="card-title">Chemotherapy Study for Breast Cancer</h5>
                    <p class="card-text">Location: Global Health Center</p>
                    <p class="card-text">Status: Ongoing</p>
                    <a href="#" class="btn btn-outline-info">View Details</a>
                </div>
            </div>
        </div>
        <!-- Repeat for other trials -->
    </div>
</div>


<div class="modal fade" id="trialDetailModal" tabindex="-1" aria-labelledby="trialDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="trialDetailModalLabel">Clinical Trial Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5>Trial on Immunotherapy for Lung Cancer</h5>
                <p><strong>Phase:</strong> II</p>
                <p><strong>Location:</strong> Cancer Research Institute</p>
                <p><strong>Status:</strong> Recruiting</p>
                <p><strong>Description:</strong> This trial investigates the effects of immunotherapy on patients with lung cancer. Eligible participants must meet specific criteria...</p>
                <p><strong>Eligibility Criteria:</strong> Ages 18+, Lung cancer diagnosis, No prior treatments...</p>
                <a href="#" class="btn btn-info">Contact Trial Coordinator</a>
            </div>
        </div>
    </div>
</div>

<!-- Trigger Button (Place this button within each trial card if desired) -->
<button type="button" class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#trialDetailModal">
  View Details
</button>



<?php
include "componet/footer.php";
?>