   <!-- Sidebar Start -->
   <div class="sidebar pe-4 pb-3">
       <nav class="navbar bg-info navbar-dark">
           <a href="index.html" class="navbar-brand mx-4 mb-3">
               <h3 class="text-white"><i class="fa fa-plus me-2"></i> XYZ Facilities</h3>
           </a>
           <div class="d-flex align-items-center ms-4 mb-4">
               <div class="position-relative">
                   <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                   <div
                       class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1">
                   </div>
               </div>
               <div class="ms-3">
                   <h6 class="mb-0 text-light">Highness James</h6>
                   <span class="text-light">Admin</span>
               </div>
           </div>
           <div class="navbar-nav w-100">
               <a href="index.php" class="nav-item nav-link"><i
                       class="fa fa-tachometer-alt me-2"></i>Dashboard</a>

               <div class="nav-item dropdown">
                   <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i
                           class="fa fa-database me-2"></i>Data Mgt </a>
                   <div class="dropdown-menu bg-transparent border-0">
                       <a href="patient_records.php" class="dropdown-item">Patient Records</a>
                       <a href="clinical_trials.php" class="dropdown-item">Clinical Trials</a>
                       <a href="genomics.php" class="dropdown-item">Genomics Data</a>
                   </div>
               </div>

               <a href="research_articles.php" class="nav-item nav-link"><i class="fa fa-book me-2"></i>Research
                   Articles</a>
               <a href="nlp_query.php" class="nav-item nav-link"><i class="fa fa-search me-2"></i>NLP Query
               </a>

               <a href="data_insights.php" class="nav-item nav-link"><i class="fa fa-chart-line me-2"></i>Data
                   Insights</a>
           </div>

       </nav>
   </div>
   <!-- Sidebar End -->

   <!-- Content Start -->
   <div class="content">
       <!-- Navbar Start -->
       <nav class="navbar navbar-expand bg-info navbar-dark sticky-top px-4 py-0">
           <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
               <h2 class="text-light mb-0"><i class="fa fa-user-edit"></i></h2>
           </a>
           <a href="#" class="sidebar-toggler flex-shrink-0">
               <i class="fa fa-bars bg-dark text-white"></i>
           </a>

           <div class="navbar-nav align-items-center ms-auto">


               <div class="nav-item dropdown">
                   <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                       <img class="rounded-circle me-lg-2" src="img/user.jpg" alt=""
                           style="width: 40px; height: 40px;">
                       <span class="d-none d-lg-inline-flex" style="color:white">Highness James</span>
                   </a>
                   <div class="dropdown-menu dropdown-menu-end bg-info border-0 rounded-0 rounded-bottom m-0">
                       <a href="#" class="dropdown-item">My Profile</a>
                       <a href="#" class="dropdown-item">Settings</a>
                       <a href="#" class="dropdown-item">Log Out</a>
                   </div>
               </div>
           </div>
       </nav>
       <!-- Navbar End -->

       <script>
           // Function to set active state in sidebar based on current URL
           function setSidebarActiveState() {
               // Get the current page path
               const currentPath = window.location.pathname;

               // Remove all active classes first
               document.querySelectorAll('.navbar-nav .active').forEach(item => {
                   item.classList.remove('active');
               });

               // Helper function to set active state and handle parent dropdowns
               function setActiveState(element) {
                   element.classList.add('active');

                   // If the item is inside a dropdown, also activate the parent dropdown link
                   const dropdownParent = element.closest('.nav-item.dropdown');
                   if (dropdownParent) {
                       dropdownParent.querySelector('.nav-link').classList.add('active');
                   }
               }

               // Special case: Check if we're on the dashboard or index page
               if (currentPath.endsWith('index.php') || currentPath === '/') {
                   const dashboardLink = document.querySelector('a[href="index.php"]');
                   if (dashboardLink) setActiveState(dashboardLink);
                   return;
               }

               // Find the link that best matches the current path
               const links = document.querySelectorAll('.navbar-nav a');
               links.forEach(link => {
                   const href = link.getAttribute('href');
                   if (href && currentPath.includes(href)) {
                       setActiveState(link);
                   }
               });
           }

           // Run when DOM is fully loaded
           document.addEventListener('DOMContentLoaded', setSidebarActiveState);

           // If using history API navigation (e.g., single-page apps), also listen for history changes
           window.addEventListener('popstate', setSidebarActiveState);
       </script>