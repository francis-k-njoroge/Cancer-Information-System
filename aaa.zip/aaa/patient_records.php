<?php
include "componet/header.php";
include "componet/sidebar.php";
?>

<div class="container-fluid pt-4 px-4">
<div class="container mt-4">
        <!-- Add New Patient Section -->
        <div class="col-12 mb-4">
            <div class="bg-light rounded py-5 border border-info h-100 p-4">
                <h2 class="mb-4">Add New Patient</h2>
                <form id="addPatientForm" action="php/add_patient.php" method="post">
                    <div class="mb-3">
                        <label for="patientName" class="form-label">Patient Name</label>
                        <input type="text" class="form-control" id="patientName" name="patientName" required>
                    </div>
                    <div class="mb-3">
                        <label for="age" class="form-label">Age</label>
                        <input type="number" class="form-control" id="age" name="age" required>
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="" selected>Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact</label>
                        <input type="text" class="form-control" id="contact" name="contact" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address">
                    </div>
                    <div class="mb-3">
                        <label for="medicalHistory" class="form-label">Medical History</label>
                        <textarea class="form-control" id="medicalHistory" name="medicalHistory" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-info">Add Patient</button>
                </form>
            </div>
        </div>

        <!-- Patient Records Table Section -->
        <div class="col-12">
            <div class="bg-light rounded py-5 border border-info h-100 p-4">
                <h6 class="mb-4">Patient Records</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-info">
                            <tr>
                                <th scope="col">Patient ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Contact</th>
                                <th scope="col">Address</th>
                                <th scope="col">Medical History</th>
                            </tr>
                        </thead>
                        <tbody id="patientRecords">
                            <!-- display data dynamically from JSON -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Function to load patient records from JSON
            function loadPatientRecords() {
                $.ajax({
                    url: 'db/patients.json', // Path to the JSON file
                    method: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        const tbody = $('#patientRecords');
                        tbody.empty(); // Clear existing records
                        data.forEach(record => {
                            const row = `
                                <tr>
                                    <td>${record.patientID}</td>
                                    <td>${record.patientName}</td>
                                    <td>${record.age}</td>
                                    <td>${record.gender}</td>
                                    <td>${record.contact}</td>
                                    <td>${record.address}</td>
                                    <td>${record.medicalHistory}</td>
                                </tr>
                            `;
                            tbody.append(row); // Append new row to the table
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading patient records:', error);
                    }
                });
            }

            // Load patient records on page load
            loadPatientRecords();

            // Handle form submission
            $('#addPatientForm').on('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission

                $.ajax({
                    url: $(this).attr('action'),
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        alert(response.message);
                        loadPatientRecords(); // Reload the patient records after adding a new one
                        $('#addPatientForm')[0].reset(); // Reset the form
                    },
                    error: function(xhr, status, error) {
                        alert('Error adding patient: ' + error);
                    }
                });
            });
        });
    </script>

</div>

<?php
include "componet/footer.php";
?>
