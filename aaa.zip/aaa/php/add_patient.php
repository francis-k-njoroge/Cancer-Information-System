<?php
header('Content-Type: application/json');

$file_path = '../db/patients.json'; // Path to your JSON file

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient data from the form
    $patientData = [
        'patientID' => uniqid(), // Generate a unique ID for the patient
        'patientName' => $_POST['patientName'],
        'age' => $_POST['age'],
        'gender' => $_POST['gender'],
        'contact' => $_POST['contact'],
        'address' => $_POST['address'],
        'medicalHistory' => $_POST['medicalHistory']
    ];

    // Read existing patient data
    $data = [];
    if (file_exists($file_path)) {
        $jsonData = file_get_contents($file_path);
        $data = json_decode($jsonData, true);
    }

    // Add new patient data
    $data[] = $patientData;

    // Save back to JSON file
    if (file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT))) {
        echo json_encode(['success' => true, 'message' => 'Patient added successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error saving data.']);
    }
}
?>
