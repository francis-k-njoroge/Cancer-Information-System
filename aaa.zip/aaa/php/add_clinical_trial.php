<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Define the JSON file path
    $file_path = '../db/clinical_trials.json';

    // Read existing data from the JSON file
    if (file_exists($file_path)) {
        $data = json_decode(file_get_contents($file_path), true);
    } else {
        $data = [];
    }

    // Append new clinical trial data
    $new_entry = [
        "title" => $title,
        "description" => $description,
        "status" => $status,
        "start_date" => $start_date,
        "end_date" => $end_date
    ];
    $data[] = $new_entry;

    // Save updated data back to the JSON file
    if (file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT))) {
         // Redirect back to clinical_trials.php after successful save
         header("Location: ../clinical_trials.php");
         exit();
    } else {
        echo "Error saving data. Please try again.";
    }
}
?>
